

import java.io.IOException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {
    public static void main(String args[]) throws IOException, ClassNotFoundException, InterruptedException{
    	Configuration conf = new Configuration();
		Job j = new Job(conf, "Output");
		j.setJarByClass(MyDriver.class);
		j.setMapperClass(MyMapper.class);
	
		j.setNumReduceTasks(1);
		j.setReducerClass(MyReducer.class);
		j.setMapOutputKeyClass(Text.class);
		j.setMapOutputValueClass(IntWritable.class);
		j.setInputFormatClass(MyInputFormat.class);
		FileSystem hdfs = FileSystem.get(conf);
		FileInputFormat.addInputPath(j, new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path (args[1]));
		Path newpath = new Path(args[1]);
		Path localfilepath = new Path("/home/hduser/outputcopy");
		if(hdfs.exists(newpath)){
			hdfs.delete(newpath,true);
		}

		if(j.waitForCompletion(true)){
			hdfs.copyToLocalFile(newpath, localfilepath);
		}
		System.exit(j.waitForCompletion(true)?0:1);

    }
}
