
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class MyValue implements Writable{
	IntWritable gen;
	
	public MyValue(){
		this.gen = new IntWritable();
	}
	public MyValue(IntWritable e){
		this.gen=e;
	}
	
	@Override
	public void readFields(DataInput arg0) throws IOException {
		gen.readFields(arg0);
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		gen.write(arg0);
	}
	
	public void setGen(IntWritable line){
		this.gen=line;
	}
	public IntWritable getGen(){
		return gen;
	}

}
