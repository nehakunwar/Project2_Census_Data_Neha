

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

@SuppressWarnings("rawtypes")
public class myKey implements WritableComparable  {
Text gen;

	
	public myKey(){
		this.gen = new Text();
	}
	public myKey(Text age){
		this.gen = gen;		
	}
	@Override
	public void readFields(DataInput arg0) throws IOException {
		gen.readFields(arg0);		
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		gen.write(arg0);
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
	public void setEdu(Text age){
		this.gen=age;
		
	}
	public Text getEdu() {
		return gen;
	}


}
