

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.LineRecordReader;

public class MyRecorder extends RecordReader {
	myKey key;
	MyValue val;
	LineRecordReader reader = new LineRecordReader();

	@Override
	public void close() throws IOException {
		reader.close();		
	}

	@Override
	public Object getCurrentKey() throws IOException, InterruptedException {
		return key;
	}

	@Override
	public Object getCurrentValue() throws IOException, InterruptedException {
		return val;
	}

	@Override
	public float getProgress() throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		return reader.getProgress();
	}

	@Override
	public void initialize(InputSplit arg0, TaskAttemptContext arg1) throws IOException, InterruptedException {
		reader.initialize(arg0, arg1);
		
	}

	@Override
	public boolean nextKeyValue() throws IOException, InterruptedException {
		boolean getnextVal = reader.nextKeyValue();
		if(getnextVal){
			if(key == null)
				key = new myKey();
			if(val == null)
				val = new MyValue();
			org.apache.hadoop.io.Text line = reader.getCurrentValue();
			String[] each = line.toString().split(",");
			key.setEdu(new Text(each[1]));
			val.setLine(new Text(each[3]));
		}
		else{
			key = null;
			val = null;	
		}
		return getnextVal;
	}


}
